#!/bin/busybox sh
# Copyright (C) 2026 Chokri Hammedi (blue0x1) <https://github.com/blue0x1>
# PS4 Multiboot initramfs: find every Linux installed on the PS4 drive or on a
# USB drive, show the boot menu, then install or boot the chosen one.
#
# A distro is identified by its short name (kali, parrot, ...):
#   /user/home/<name>-ps4-rootfs.tar.xz   archive to install from (copied over FTP;
#                                         .tar.gz and .tar.bz2 work too)
#   /user/home/<name>-ps4.img             installed on the PS4 drive
#   ext4 labeled <NAME>-PS4               installed on a USB drive
#
# Kernel cmdline options (all optional):
#   ps4_default=<name>     card selected at start (default: the first installed)
#   ps4_root=<spec>        boot this root directly, no menu; LABEL=, UUID= or /dev/...
#   ps4_rootwait=<sec>     how long to wait for USB drives (default 10, or 30
#                          when the loader gave no PS4 drive key)
#   ps4_rescue             open a shell before anything else
#   ps4_disk_size=<size>   size of a new disk on the PS4 drive, without asking:
#                          GB (24 or 24G) or MB (24576M); kept between the
#                          distro's minimum and what the PS4 drive can spare
# The Kali for PS4 names (kali_root=, kali_rootwait=, kali_rescue) still work.

/bin/busybox --install -s /bin
export PATH=/bin

mount -t devtmpfs devtmpfs /dev
mount -t proc proc /proc
mount -t sysfs sysfs /sys

root_spec=""
rootwait=""
rescue=0
default_id=""
disk_size_arg=""
for arg in $(cat /proc/cmdline); do
    case "$arg" in
        ps4_root=*|kali_root=*)         root_spec="${arg#*_root=}" ;;
        ps4_rootwait=*|kali_rootwait=*) rootwait="${arg#*_rootwait=}" ;;
        ps4_rescue|kali_rescue)         rescue=1 ;;
        ps4_default=*)                  default_id="${arg#ps4_default=}" ;;
        ps4_disk_size=*)                disk_size_arg="${arg#ps4_disk_size=}" ;;
    esac
done
if [ -z "$rootwait" ]; then
    rootwait=30
    [ -r /key/eap_hdd_key.bin ] && rootwait=10
fi

msg() { echo "ps4-linux: $*"; echo "ps4-linux: $*" > /dev/kmsg 2>/dev/null; }

# Writes the kernel log to the FAT32 boot partition (LABEL=PS4BOOT) so a boot
# with no display or network can still be diagnosed on another computer.
save_log() {
    bd="$(findfs LABEL=PS4BOOT 2>/dev/null)" || return 0
    mkdir -p /bootfs
    mount -t vfat "$bd" /bootfs 2>/dev/null || return 0
    {
        echo "== ps4-linux initramfs log: $1"
        echo "uptime: $(cut -d' ' -f1 /proc/uptime)s"
        echo "cmdline: $(cat /proc/cmdline)"
        uname -a
        echo "== /sys/class/drm"; ls /sys/class/drm 2>&1
        echo "== dmesg"; dmesg
    } > "/bootfs/ps4-linux-$2.log" 2>&1
    sync
    umount /bootfs
}

rescue_shell() {
    [ -x /bin/fbui ] && fbui text
    msg "$1"
    save_log "$1" rescue
    msg "rescue shell - mount the root on /newroot by hand, or type 'exit' to retry"
    setsid cttyhack sh || sh
}

# --- Distros ----------------------------------------------------------------
# Each archive starts with etc/ps4-distro/name and etc/ps4-distro/logo.rgba
# (added by build-rootfs.sh), so the menu shows any distro's own name and
# logo. Older archives without them use the names and logos built in here.
LOGOS=/etc/ps4/logos
META=/run/meta
ARCHIVE_EXTS="tar.xz tar.gz tar.bz2"

# The archive file of distro $1 on the PS4 drive (any supported extension).
archive_of() {
    for e in $ARCHIVE_EXTS; do
        [ -f "/ps4hdd/home/$1-ps4-rootfs.$e" ] && { echo "/ps4hdd/home/$1-ps4-rootfs.$e"; return 0; }
    done
    return 1
}

# Decompresses stdin to stdout, by the extension of archive $1. "mt" as $2
# uses all CPU cores where possible (XZ Utils).
unpack() {
    case "$1" in
        *.gz)  gzip -dc ;;
        *.bz2) bzip2 -dc ;;
        *)     if [ "$2" = mt ] && [ -x /bin/xz-mt ]; then xz-mt -T0 -dc; else xz -dc; fi ;;
    esac
}

# The distro's own logo inside a root filesystem ($1): the icon named by
# LOGO= in os-release, else <id>-logo, distributor-logo-<id> or <id> (PNG or
# JPEG) under usr/share/pixmaps and usr/share/icons; the largest file wins.
find_logo() {
    local osr id icon n best
    osr="$1/etc/os-release"; [ -f "$osr" ] || osr="$1/usr/lib/os-release"
    id="$(sed -n 's/^ID=//p' "$osr" 2>/dev/null | tr -d '"')"
    icon="$(sed -n 's/^LOGO=//p' "$osr" 2>/dev/null | tr -d '"')"
    for n in "$icon" "${id:+$id-logo}" "${id:+distributor-logo-$id}" "$id"; do
        [ -n "$n" ] || continue
        best="$(find "$1/usr/share/pixmaps" "$1/usr/share/icons" \( -name "$n.png" -o -name "$n.jpg" \) 2>/dev/null \
            | while read -r f; do echo "$(stat -L -c %s "$f" 2>/dev/null || echo 0) $f"; done \
            | sort -rn | head -n 1 | cut -d' ' -f2-)"
        [ -n "$best" ] && { echo "$best"; return 0; }
    done
    return 1
}

# Reads the name and logo from the first 4 MB of an archive: $1 id, $2 file.
meta_from_archive() {
    [ -s "$META/$1/etc/ps4-distro/name" ] && [ -s "$META/$1/etc/ps4-distro/logo.rgba" ] && return 0
    mkdir -p "$META/$1"
    head -c 4194304 "$2" | unpack "$2" 2>/dev/null | tar -x -C "$META/$1" ./etc/ps4-distro 2>/dev/null
    return 0
}

# Archives without etc/ps4-distro (any distro's own rootfs archive): read the
# whole archive in the background while the menu is up and keep only its
# os-release and logo files; the menu card shows the logo once it is found.
# $1 id, $2 file. Leaves $META/<id>/scan.done when finished.
scan_pids=""
scan_archive() {
    d="$META/$1"
    [ -s "$d/etc/ps4-distro/logo.rgba" ] || [ -e "$d/scan.started" ] && return 0
    [ -x /bin/fbui ] || return 0
    mkdir -p "$d/etc/ps4-distro"
    touch "$d/scan.started"
    (
        unpack "$2" mt < "$2" 2>/dev/null | fbui scan "$d/scan" etc/os-release usr/lib/os-release \
            'usr/share/pixmaps/*' 'usr/share/icons/*logo*' 2>/dev/null
        src="$(find_logo "$d/scan")" && fbui logo "$src" "$d/logo.tmp" > /dev/null 2>&1 \
            && mv "$d/logo.tmp" "$d/etc/ps4-distro/logo.rgba"
        rm -rf "$d/scan"
        touch "$d/scan.done"
    ) < /dev/null > /dev/null 2>&1 &
    scan_pids="$scan_pids $!"
    return 0
}

# Waits up to $2 seconds for the scan of $1 to finish.
scan_wait() {
    [ -d "$META/$1/etc/ps4-distro" ] || return 0
    i=0
    while [ ! -e "$META/$1/scan.done" ] && [ ! -s "$META/$1/etc/ps4-distro/logo.rgba" ] && [ "$i" -lt "$2" ]; do
        sleep 1; i=$((i + 1))
    done
}

# Stops all scans (they read from the PS4 drive, which must be unmounted).
scan_stop() {
    [ -n "$scan_pids" ] || return 0
    for p in $(pidof xz-mt xz) ; do kill "$p" 2>/dev/null; done
    for p in $scan_pids; do wait "$p" 2>/dev/null; done
    scan_pids=""
}

# Same from an installed distro, read-only: $1 id, $2 USB device or image
# file on the PS4 drive. Uses etc/ps4-distro if the installer saved it there,
# else looks for the distro's own logo.
meta_from_root() {
    [ -s "$META/$1/etc/ps4-distro/logo.rgba" ] && return 0
    mkdir -p "$META/$1/etc/ps4-distro" /run/metamnt
    if mount -t ext4 -o ro,noload "$2" /run/metamnt 2>/dev/null; then
        cp /run/metamnt/etc/ps4-distro/* "$META/$1/etc/ps4-distro/" 2>/dev/null
        if [ ! -s "$META/$1/etc/ps4-distro/logo.rgba" ] && [ -x /bin/fbui ] && src="$(find_logo /run/metamnt)"; then
            fbui logo "$src" "$META/$1/etc/ps4-distro/logo.rgba" > /dev/null 2>&1
        fi
        umount -d /run/metamnt 2>/dev/null || umount /run/metamnt
    fi
    return 0
}

name_of() {
    if [ -s "$META/$1/etc/ps4-distro/name" ]; then
        head -n 1 "$META/$1/etc/ps4-distro/name" | tr -d '|'
        return 0
    fi
    case "$1" in
        kali)   echo "Kali Linux" ;;
        parrot) echo "Parrot OS" ;;
        ubuntu) echo "Ubuntu" ;;
        debian) echo "Debian" ;;
        arch)   echo "Arch Linux" ;;
        fedora) echo "Fedora" ;;
        *)      first="$(echo "${1%"${1#?}"}" | tr a-z A-Z)"; echo "$first${1#?}" ;;
    esac
}

logo_of() {
    if [ -s "$META/$1/etc/ps4-distro/logo.rgba" ]; then echo "$META/$1/etc/ps4-distro/logo.rgba"
    elif [ -f "$LOGOS/$1.rgba" ]; then echo "$LOGOS/$1.rgba"
    elif [ -d "$META/$1/etc/ps4-distro" ] && [ ! -e "$META/$1/scan.done" ]; then
        echo "$META/$1/etc/ps4-distro/logo.rgba"     # still being read
    else echo "-"; fi
}

# Makes $1 the distro every function below works on.
D=""; DNAME=""; DLABEL=""; HDD_IMG=""; HDD_TAR=""; UI_IMG=""
select_distro() {
    D="$1"
    DNAME="$(name_of "$1")"
    DLABEL="$(echo "$1" | tr a-z A-Z | cut -c1-12)-PS4"   # ext4 labels: 16 characters
    HDD_IMG="home/$1-ps4.img"
    HDD_TAR="home/$1-ps4-rootfs.tar.xz"
    a="$(archive_of "$1")" && HDD_TAR="${a#/ps4hdd/}"
    UI_IMG="$(logo_of "$1")"
    export FBUI_TITLE="$DNAME for PS4" FBUI_NAME="$DNAME"
    ui_asked=0
    img_created=0
    install_target=hdd
}

# --- Install and progress screens (fbui.c) ----------------------------------
ui_asked=0
img_created=0

# First USB disk of at least 8 GB that is not the PS4's own drive (the one
# with partition 27). Sets usb_dev (/dev/sdX) and usb_desc ("Model, 64 GB").
usb_dev=""
usb_desc=""
find_usb_disk() {
    usb_dev=""; usb_desc=""
    for b in /sys/block/sd*; do
        [ -e "$b/size" ] || continue
        n="${b##*/}"
        [ -e "$b/${n}27" ] && continue
        case "$(readlink -f "$b")" in */usb*) ;; *) continue ;; esac
        gb=$(( $(cat "$b/size") / 2097152 ))
        [ "$gb" -ge 8 ] || continue
        model="$(cat "$b/device/vendor" "$b/device/model" 2>/dev/null | tr -s ' \n' ' ')"
        model="${model% }"; model="${model# }"
        usb_dev="/dev/$n"
        usb_desc="${model:-USB drive}, $gb GB"
        # Say what is on it, since installing erases it.
        on="$(blkid "$usb_dev" 2>/dev/null | sed -n 's/.*LABEL="\([A-Za-z0-9]*\)-PS4".*/\1/p')"
        [ -n "$on" ] && usb_desc="$usb_desc, has $(name_of "$(echo "$on" | tr A-Z a-z)")"
        return 0
    done
    return 1
}

# Leave without writing anything. The PS4 drive is only mounted read-only.
ui_reboot() {
    msg "reboot chosen"
    [ -x /bin/fbui ] && fbui msg "${UI_IMG:--}" "Restarting the PS4..."
    hdd_close
    sync
    sleep 2
    reboot -f
}

# Install screen. Sets install_target to hdd (the PS4 drive), usb, or back
# (only offered when FBUI_BACK is set, i.e. when coming from the menu). With
# no input for 60 s it installs to the PS4 drive.
install_target=hdd
ui_welcome() {
    [ "$ui_asked" = 1 ] && return 0
    ui_asked=1
    usb_desc=""
    [ "$1" = nousb ] || find_usb_disk
    msg "waiting for the Install button for $DNAME${usb_dev:+ (USB drive $usb_dev: $usb_desc)}"
    if [ -x /bin/fbui ]; then
        fbui welcome "$UI_IMG" "$usb_desc"
        case $? in
            10) [ -n "$usb_dev" ] && install_target=usb ;;
            20) ui_reboot ;;
            30) install_target=back ;;
        esac
    fi
    msg "install target: $install_target"
}

# stdin -> stdout with the progress bar: FROM% TO% SIZE LABEL
ui_progress() {
    if [ -x /bin/fbui ]; then fbui progress "$UI_IMG" "$@"; else cat; fi
}

ui_step() { ui_progress "$1" "$1" 1 "$2" < /dev/null > /dev/null; }

# "Still working" screen (full bar, spinning arc) while data is flushed to
# the drive, which can take minutes on a slow USB stick.
busy_pid=""
ui_busy() {
    [ -x /bin/fbui ] || return 0
    fbui busy "$UI_IMG" "$1" &
    busy_pid=$!
}

ui_busy_end() {
    [ -n "$busy_pid" ] || return 0
    kill "$busy_pid" 2>/dev/null
    wait "$busy_pid" 2>/dev/null
    busy_pid=""
}

# Error screen with two buttons: Back (to the menu, or Restart when there
# is no menu) and Text mode (the rescue console). The answer is kept in
# ui_answer (back or text) for back_or_shell.
ui_answer=""
ui_back_label="Restart the PS4"
ui_error() {
    msg "$1"
    [ -x /bin/fbui ] || return 0
    if fbui fail "${UI_IMG:--}" "$1" "$ui_back_label"; then
        ui_answer=back
    else
        ui_answer=text
    fi
    msg "error screen: $ui_answer"
}

# After a failed boot or install: asks Back or Text mode (unless an error
# screen already did), then goes back to the menu (returns 0, the caller
# continues), restarts the PS4 (no menu to go back to), or opens the rescue
# console.
back_or_shell() {
    [ -n "$ui_answer" ] || ui_error "$1"
    a="$ui_answer"; ui_answer=""
    case "$a" in
        back) [ "$ui_back_label" = "Back to the menu" ] && return 0
              ui_reboot ;;
    esac
    rescue_shell "$1"
}
# ----------------------------------------------------------------------------

# --- PS4 setup for any distro ----------------------------------------------
# Any normal x86_64 Linux rootfs archive can be installed: after unpacking it,
# the installer adds what the PS4 needs from etc/ps4/kit in this initramfs.
KIT=/etc/ps4/kit

# Is there an init to start? (/sbin/init is usually a symlink into the new
# root, so test the link itself too.)
has_init() {
    [ -e /newroot/sbin/init ] || [ -L /newroot/sbin/init ] || [ -e /newroot/usr/lib/systemd/systemd ]
}

# The new root's lib folder (often a symlink to usr/lib).
newroot_lib() {
    if [ -L /newroot/lib ]; then
        t="$(readlink /newroot/lib)"
        case "$t" in /*) echo "/newroot$t" ;; *) echo "/newroot/$t" ;; esac
    else
        echo /newroot/lib
    fi
}

# Some archives keep the system in one top folder (root.x86_64/, rootfs/...).
flatten_root() {
    [ -e /newroot/etc ] && return 0
    set -- /newroot/*
    [ "$#" = 1 ] && [ -d "$1/etc" ] || return 0
    msg "moving $1 up to the root"
    mv "$1" /newroot/.ps4top
    for f in /newroot/.ps4top/* /newroot/.ps4top/.[!.]*; do
        [ -e "$f" ] || [ -L "$f" ] && mv "$f" /newroot/
    done
    rmdir /newroot/.ps4top
    return 0
}

# Copies the PS4 kernel modules for the running kernel if they are missing
# (a new kernel was copied to the PS4 after the install).
ensure_modules() {
    k="$(uname -r)"; l="$(newroot_lib)"
    [ -d "$l/modules/$k" ] || [ ! -d "$KIT/modules/$k" ] && return 0
    ro=0
    grep ' /newroot ' /proc/mounts | grep -q ' ro[ ,]' && ro=1
    [ "$ro" = 1 ] && mount -o remount,rw /newroot
    mkdir -p "$l/modules" && cp -a "$KIT/modules/$k" "$l/modules/" && msg "added kernel modules $k"
    [ "$ro" = 1 ] && mount -o remount,ro /newroot
    return 0
}

# Runs a command inside the new root with the usual system PATH.
in_root() {
    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin chroot /newroot "$@"
}

# 3D graphics (OpenGL and Vulkan on the PS4 GPU) come from the PS4 Mesa
# bundle, when the user copied it to /user/home/ps4-mesa.tar.xz. Called while
# the PS4 drive is still mounted, only for an install; the copy goes to RAM.
MESA=""
mesa_pick() {
    MESA=""
    if [ -f /ps4hdd/home/ps4-mesa.tar.xz ] && cp /ps4hdd/home/ps4-mesa.tar.xz /run/ps4-mesa.tar.xz; then
        MESA=/run/ps4-mesa.tar.xz
        msg "3D graphics: using /user/home/ps4-mesa.tar.xz"
    fi
    return 0
}

# Does the new root have glibc 2.38 or newer (what the PS4 Mesa needs)?
root_glibc_ok() {
    for f in usr/lib/x86_64-linux-gnu/libc.so.6 lib/x86_64-linux-gnu/libc.so.6 usr/lib64/libc.so.6 usr/lib/libc.so.6; do
        [ -f "/newroot/$f" ] && { grep -q 'GLIBC_2\.38' "/newroot/$f"; return; }
    done
    return 1
}

# Adds the PS4 Mesa to the new root and makes it the system's driver, with
# GPU acceleration for the desktop. Without it (or with an older glibc) the
# distro keeps software rendering.
mesa_setup() {
    [ -n "$MESA" ] || return 0
    if ! root_glibc_ok; then
        msg "3D graphics: $DNAME has glibc older than 2.38, keeping software rendering"
        return 0
    fi
    ui_busy "Adding 3D graphics for the PS4 GPU..."
    rm -rf /newroot/opt/ps4-mesa
    mkdir -p /newroot/opt
    if unpack "$MESA" mt < "$MESA" | tar -x -C /newroot \
       && in_root /opt/ps4-mesa/bin/ps4-mesa-enable > /dev/kmsg 2>&1; then
        msg "3D graphics: PS4 Mesa added"
    else
        msg "3D graphics: could not add the PS4 Mesa, keeping software rendering"
        [ -x /newroot/opt/ps4-mesa/bin/ps4-mesa-enable ] \
            && in_root /opt/ps4-mesa/bin/ps4-mesa-enable --undo > /dev/kmsg 2>&1
        rm -rf /newroot/opt/ps4-mesa
    fi
    ui_busy_end
    return 0
}

ps4_setup() {
    r=/newroot; k="$(uname -r)"; l="$(newroot_lib)"
    msg "PS4 setup for $DNAME"

    # Kernel modules and firmware for the PS4 kernel.
    mkdir -p "$l/modules" "$l/firmware/amdgpu" "$l/firmware/edid"
    if [ -d "$KIT/modules/$k" ]; then
        rm -rf "$l/modules/$k"
        cp -a "$KIT/modules/$k" "$l/modules/"
    fi
    cp -a "$KIT/firmware/." "$l/firmware/" 2>/dev/null

    # Keep the Slim/Pro HDMI output on (the same helper as in this initramfs).
    mkdir -p "$r/usr/local/sbin"
    cp /bin/ps4hdmi "$r/usr/local/sbin/ps4hdmi"
    if [ -d "$r/etc/systemd" ] && [ ! -e "$r/etc/systemd/system/ps4-hdmi-keepalive.service" ]; then
        mkdir -p "$r/etc/systemd/system/multi-user.target.wants"
        printf '%s\n' '[Unit]' 'Description=Keep the PS4 Slim/Pro HDMI bridge output on' \
            '[Service]' 'ExecStart=/usr/local/sbin/ps4hdmi' 'Restart=always' 'RestartSec=5' \
            '[Install]' 'WantedBy=multi-user.target' > "$r/etc/systemd/system/ps4-hdmi-keepalive.service"
        ln -sf ../ps4-hdmi-keepalive.service "$r/etc/systemd/system/multi-user.target.wants/"
    fi

    # X display settings: software rendering, since the distro's own Mesa
    # misreads the PS4 GPU. mesa_setup switches it to the GPU when it can.
    if [ ! -e "$r/etc/X11/xorg.conf.d/20-ps4-gpu.conf" ]; then
        mkdir -p "$r/etc/X11/xorg.conf.d"
        cp "$KIT/20-ps4-gpu.conf" "$r/etc/X11/xorg.conf.d/"
    fi
    mesa_setup

    # Menu name and logo, kept in the installed system (the menu reads them
    # from there on later boots). Our archives already have them.
    mkdir -p "$r/etc/ps4-distro"
    [ -s "$r/etc/ps4-distro/name" ] || echo "$DNAME" > "$r/etc/ps4-distro/name"
    if [ ! -s "$r/etc/ps4-distro/logo.rgba" ] && [ -x /bin/fbui ] && src="$(find_logo "$r")"; then
        fbui logo "$src" "$r/etc/ps4-distro/logo.rgba" && msg "logo: ${src#/newroot}"
    fi
    [ -s "$r/etc/ps4-distro/logo.rgba" ] && UI_IMG="$r/etc/ps4-distro/logo.rgba"

    # Hostname and the root filesystem by label.
    echo "$D-ps4" > "$r/etc/hostname"
    { [ -f "$r/etc/hosts" ] && grep -v '^127\.0\.1\.1' "$r/etc/hosts"
      printf '127.0.1.1\t%s\n' "$D-ps4"; } > /run/hosts.new
    cat /run/hosts.new > "$r/etc/hosts"
    { echo "LABEL=$DLABEL / ext4 defaults,noatime 0 1"
      [ -f "$r/etc/fstab" ] && awk '$2 != "/"' "$r/etc/fstab"; } > /run/fstab.new
    cat /run/fstab.new > "$r/etc/fstab"

    # A login when the archive has none: user <distro>, password <distro>
    # (root gets the same password, since sudo may not be installed).
    if ! awk -F: '$3 >= 1000 && $3 < 60000 { f = 1 } END { exit !f }' "$r/etc/passwd" 2>/dev/null; then
        user="$(echo "$D" | tr -cd 'a-z0-9')"; [ -n "$user" ] || user=ps4
        sh=/bin/sh; [ -x "$r/bin/bash" ] && sh=/bin/bash
        grp=""
        for g in sudo wheel; do grep -q "^$g:" "$r/etc/group" && grp="$g" && break; done
        mount --bind /dev "$r/dev" 2>/dev/null
        mount -t proc proc "$r/proc" 2>/dev/null
        if in_root /bin/sh -c 'command -v useradd' > /dev/null 2>&1; then
            in_root useradd -m -s "$sh" ${grp:+-G "$grp"} "$user"
        else
            in_root adduser -D -s "$sh" "$user" && [ -n "$grp" ] && in_root addgroup "$user" "$grp"
        fi
        printf '%s:%s\nroot:%s\n' "$user" "$user" "$user" | in_root chpasswd \
            && msg "created login $user (password $user)"
        umount "$r/proc" 2>/dev/null
        umount "$r/dev" 2>/dev/null
    fi
    return 0
}
# ----------------------------------------------------------------------------

# --- PS4 internal drive -----------------------------------------------------
# The PS4 user partition is unlocked with the console key that
# ps4-linux-loader provides and mounted READ-ONLY to find the distros and map
# their image files; Linux never writes the PS4's filesystem, only inside the
# image files (and once, to create a new image file during an install).
hdd_is_open=0

hdd_open() {
    [ "$hdd_is_open" = 1 ] && return 0
    [ -r /key/eap_hdd_key.bin ] || { msg "hdd: loader gave no drive key"; return 1; }
    for t in cryptsetup dmsetup blockmap; do
        [ -x "/bin/$t" ] || { msg "hdd: $t missing in initramfs"; return 1; }
    done
    export DM_DISABLE_UDEV=1

    part=""; i=0
    while [ "$i" -lt 15 ] && [ -z "$part" ]; do
        for p in /dev/sd?27; do [ -b "$p" ] && part="$p" && break; done
        [ -n "$part" ] || { sleep 1; i=$((i + 1)); }
    done
    [ -n "$part" ] || { msg "hdd: PS4 user partition (sdX27) not found"; return 1; }

    # Aeolia (CUH-10xx/11xx) uses no IV offset; Belize and Baikal mix in the
    # partition position (same values as the community internal-HDD initramfs).
    # The southbridge says which one comes first. When the filesystem does not
    # show up that way, the other one is tried: some consoles do not match
    # their southbridge's rule. Both tries only read the drive.
    sb="$(cat /sys/bus/pci/devices/0000:00:14.0/device 2>/dev/null)"
    skips="111669149696 0"
    [ "$sb" = 0x908f ] && skips="0 111669149696"
    mkdir -p /ps4hdd
    for skip in $skips; do
        cryptsetup --disable-locks -d /key/eap_hdd_key.bin --cipher aes-xts-plain64 -s 256 \
            --offset 0 --skip "$skip" create ps4hdd "$part" > /dev/kmsg 2>&1 \
            || { msg "hdd: could not unlock $part"; return 1; }
        if mount -t ufs -o ro,ufstype=ufs2 /dev/mapper/ps4hdd /ps4hdd 2> /dev/kmsg; then
            [ "$skip" = "${skips%% *}" ] || msg "hdd: unlocked with IV offset $skip (southbridge ${sb:-unknown})"
            hdd_is_open=1
            return 0
        fi
        cryptsetup --disable-locks remove ps4hdd
    done
    msg "hdd: could not mount PS4 user partition (read-only), southbridge ${sb:-unknown}"
    return 1
}

# Unmounts the PS4 filesystem and removes every mapping on it.
hdd_close() {
    scan_stop
    grep -q ' /ps4hdd ' /proc/mounts && umount /ps4hdd
    for m in disttar distimg; do
        [ -b "/dev/mapper/$m" ] && dmsetup --noudevsync remove "$m"
    done
    [ -b /dev/mapper/ps4hdd ] && cryptsetup --disable-locks remove ps4hdd
    hdd_is_open=0
}

# First boot of a distro: <name>-ps4.img is a new, all-zero file and the
# archive sits next to it. Format the image and unpack the archive into it.
# Anything that is not all zeros is left alone.
first_boot_install() {
    if [ -n "$(dd if=/dev/mapper/distimg bs=1M count=1 2>/dev/null | hexdump -v -e '/1 "%02x"' | tr -d 0)" ]; then
        msg "hdd: /user/$HDD_IMG is neither ext4 nor empty; refusing to touch it"
        return 1
    fi
    if [ -z "$tar_size" ] || ! [ -b /dev/mapper/disttar ]; then
        msg "hdd: /user/$HDD_IMG is empty and /user/$HDD_TAR is missing; nothing to install"
        return 1
    fi
    [ -x /bin/mke2fs ] || { msg "hdd: mke2fs missing in initramfs"; return 1; }

    ui_welcome nousb
    from=0; [ "$img_created" = 1 ] && from=25
    msg "installing $DNAME into /user/$HDD_IMG (about 10 minutes, do not turn off)"
    ui_step "$from" "Preparing the $DNAME disk"
    /bin/mke2fs -q -F -t ext4 -L "$DLABEL" -m 1 /dev/mapper/distimg > /dev/kmsg 2>&1 \
        || { ui_error "Installation failed: could not format the $DNAME disk"; return 1; }
    mount -t ext4 /dev/mapper/distimg /newroot \
        || { ui_error "Installation failed: could not mount the $DNAME disk"; return 1; }

    if head -c "$tar_size" /dev/mapper/disttar | ui_progress "$from" 100 "$tar_size" "Installing $DNAME" \
       | unpack "$HDD_TAR" | tar -x -C /newroot && flatten_root && has_init; then
        ps4_setup
        ui_busy "Finishing: writing data to the PS4 drive..."
        sync
        msg "$DNAME installed ($(du -sm /newroot | cut -f1) MB). Starting $DNAME."
        ui_busy_end
        [ -x /bin/fbui ] && fbui done "$UI_IMG" "$DNAME is installed. Starting..." && sleep 3
        return 0
    fi
    umount /newroot
    ui_error "Installation failed: could not unpack /user/$HDD_TAR"
    return 1
}

# Creates the image file once (16 GiB, or less if space is short; at least
# 8 GiB, always leaving 10 GiB free for the PS4). This is the only time Linux
# writes the PS4's filesystem: one new, fully allocated file. Then it is
# read-only again.
HDD_IMG_MB=16384        # suggested size
HDD_MIN_MB=4096         # never smaller
HDD_ROOM_MB=4096        # room on top of the unpacked distro (updates, swap, games)
HDD_KEEP_FREE_MB=10240  # always left free for the PS4 itself

# Smallest disk for the selected distro, in MB: its unpacked size plus
# HDD_ROOM_MB, rounded up to an even number of GB, at least HDD_MIN_MB. XZ
# Utils reads the unpacked size from the archive's index in a moment; other
# archives are guessed at four times their size.
min_image_mb() {
    local f="/ps4hdd/$HDD_TAR" mb=""
    case "$f" in
        *.xz) [ -x /bin/xz-mt ] && mb=$(xz-mt --robot -l "$f" 2>/dev/null \
                  | awk '$1 == "totals" { printf "%d", $5 / 1048576 + 1 }') ;;
    esac
    [ -n "$mb" ] || mb=$(( $(stat -c %s "$f" 2>/dev/null || echo 0) * 4 / 1048576 ))
    mb=$(( (mb + HDD_ROOM_MB + 2047) / 2048 * 2048 ))
    [ "$mb" -lt "$HDD_MIN_MB" ] && mb=$HDD_MIN_MB
    echo "$mb"
}

# ps4_disk_size= in MB ("24", "24G" and "24g" are GB, "24576M" MB), or nothing.
disk_size_arg_mb() {
    case "$disk_size_arg" in
        "") ;;
        *[Mm]) n="${disk_size_arg%[Mm]}"; case "$n" in ''|*[!0-9]*) ;; *) echo "$n" ;; esac ;;
        *)     n="${disk_size_arg%[Gg]}"; case "$n" in ''|*[!0-9]*) ;; *) echo $(( n * 1024 )) ;; esac ;;
    esac
}

create_image() {
    free_mb=$(df -m /ps4hdd | awk 'NR==2{print $4}')
    min_mb=$(min_image_mb)
    max_mb=$(( ${free_mb:-0} - HDD_KEEP_FREE_MB ))
    max_mb=$(( max_mb / 1024 * 1024 ))
    msg "disk size: minimum $min_mb MB, at most $max_mb MB (${free_mb:-?} MB free, $HDD_KEEP_FREE_MB MB kept for the PS4)"
    if [ "$max_mb" -lt "$min_mb" ]; then
        ui_welcome
        ui_error "Not enough free space for $DNAME: $(( ${free_mb:-0} / 1024 )) GB free on the PS4, $(( (min_mb + HDD_KEEP_FREE_MB) / 1024 )) GB needed"
        return 1
    fi
    # Nothing is written to the PS4 drive before the Install button.
    ui_welcome
    size_mb=$HDD_IMG_MB
    [ "$size_mb" -gt "$max_mb" ] && size_mb=$max_mb
    [ "$size_mb" -lt "$min_mb" ] && size_mb=$min_mb
    arg_mb=$(disk_size_arg_mb)
    if [ -n "$arg_mb" ]; then
        size_mb=$arg_mb
        [ "$size_mb" -gt "$max_mb" ] && size_mb=$max_mb
        [ "$size_mb" -lt "$min_mb" ] && size_mb=$min_mb
        msg "disk size from ps4_disk_size=$disk_size_arg: $size_mb MB"
    elif [ -x /bin/fbui ]; then
        gb=$(fbui disksize "$UI_IMG" $(( min_mb / 1024 )) $(( max_mb / 1024 )) $(( size_mb / 1024 )) \
                 $(( ${free_mb:-0} / 1024 )) 2>/dev/null)
        case "$gb" in ''|*[!0-9]*) ;; *) size_mb=$(( gb * 1024 )) ;; esac
        [ "$size_mb" -gt "$max_mb" ] && size_mb=$max_mb
        [ "$size_mb" -lt "$min_mb" ] && size_mb=$min_mb
        msg "disk size chosen: $size_mb MB"
    fi
    if ! mount -o remount,rw /ps4hdd; then
        ui_error "Installation failed: could not open the PS4 drive for writing"
        return 1
    fi
    msg "creating /user/$HDD_IMG ($((size_mb / 1024)) GB, a few minutes, do not turn off)"
    bytes=$((size_mb * 1048576))
    if head -c "$bytes" /dev/zero | ui_progress 0 25 "$bytes" "Creating the $DNAME disk on your PS4" \
           > "/ps4hdd/$HDD_IMG" && sync && [ "$(stat -c %s "/ps4hdd/$HDD_IMG")" = "$bytes" ]; then
        mount -o remount,ro /ps4hdd
        img_created=1
        msg "image created"
        return 0
    fi
    ui_error "Installation failed: could not create the $DNAME disk"
    msg "removing the partial file"
    rm -f "/ps4hdd/$HDD_IMG"
    sync
    mount -o remount,ro /ps4hdd
    return 1
}

# Installs the distro from /user/$HDD_TAR (PS4 drive, mounted read-only) onto
# the whole USB drive $usb_dev, erasing it. Later boots find it by its label.
usb_install() {
    tsize=$(stat -c %s "/ps4hdd/$HDD_TAR")
    mkdir -p /run
    if ! blockmap "/ps4hdd/$HDD_TAR" /dev/mapper/ps4hdd > /run/dist-tar.table; then
        hdd_close
        ui_error "Installation failed: could not read /user/$HDD_TAR"
        return 1
    fi
    mesa_pick
    scan_stop
    umount /ps4hdd
    if ! dmsetup --noudevsync create disttar < /run/dist-tar.table > /dev/kmsg 2>&1; then
        hdd_close
        ui_error "Installation failed: could not read /user/$HDD_TAR"
        return 1
    fi

    ok=0
    msg "installing $DNAME onto $usb_dev ($usb_desc)"
    ui_step 0 "Preparing the USB drive"
    # Old partition tables (at the start, and the GPT copy at the end) would
    # hide the new filesystem, so clear both before formatting the whole disk.
    sectors=$(cat "/sys/block/${usb_dev#/dev/}/size")
    dd if=/dev/zero of="$usb_dev" bs=1M count=4 conv=fsync 2>/dev/null
    dd if=/dev/zero of="$usb_dev" bs=512 seek=$((sectors - 8192)) count=8192 conv=fsync 2>/dev/null
    if ! /bin/mke2fs -q -F -t ext4 -L "$DLABEL" -m 1 "$usb_dev" > /dev/kmsg 2>&1; then
        ui_error "Installation failed: could not format the USB drive"
    elif ! mount -t ext4 "$usb_dev" /newroot; then
        ui_error "Installation failed: could not mount the USB drive"
    elif head -c "$tsize" /dev/mapper/disttar \
            | ui_progress 0 100 "$tsize" "Installing $DNAME onto the USB drive" \
            | unpack "$HDD_TAR" | tar -x -C /newroot && flatten_root && has_init; then
        ps4_setup
        ui_busy "Finishing: writing data to the USB drive..."
        sync
        ok=1
        msg "$DNAME installed on $usb_dev ($(du -sm /newroot | cut -f1) MB). Starting $DNAME."
        ui_busy_end
        [ -x /bin/fbui ] && fbui done "$UI_IMG" "$DNAME is installed on the USB drive. Starting..." && sleep 3
    else
        umount /newroot
        ui_error "Installation failed: could not unpack /user/$HDD_TAR"
    fi
    hdd_close
    [ "$ok" = 1 ]
}

# Boots (installing first if needed) the selected distro from the PS4 drive.
# Expects hdd_open to have run. Leaves the root mounted on /newroot.
hdd_boot() {
    hdd_open || return 1
    if [ ! -f "/ps4hdd/$HDD_IMG" ]; then
        if [ ! -f "/ps4hdd/$HDD_TAR" ]; then
            msg "hdd: no /user/$HDD_IMG or /user/$HDD_TAR on the PS4 drive"
            hdd_close
            return 1
        fi
        ui_welcome
        if [ "$install_target" = usb ]; then
            usb_install
            return $?
        fi
        create_image || { hdd_close; return 1; }
    fi
    mkdir -p /run
    if ! blockmap "/ps4hdd/$HDD_IMG" /dev/mapper/ps4hdd > /run/dist-img.table; then
        msg "hdd: could not map /user/$HDD_IMG (holes or unsupported)"
        hdd_close
        return 1
    fi
    msg "hdd: image mapped in $(wc -l < /run/dist-img.table) extents"
    # The archive is mapped the same way, so the PS4 filesystem can be
    # unmounted before either mapping is created (the device-mapper cannot
    # use the partition while it is mounted).
    tar_size=""
    if [ -f "/ps4hdd/$HDD_TAR" ] && blockmap "/ps4hdd/$HDD_TAR" /dev/mapper/ps4hdd > /run/dist-tar.table; then
        tar_size=$(stat -c %s "/ps4hdd/$HDD_TAR")
    fi
    # An install follows when the image is not ext4 yet: get its 3D graphics
    # bundle while the PS4 filesystem is still mounted.
    if [ -n "$tar_size" ] && [ "$(dd if="/ps4hdd/$HDD_IMG" bs=1 skip=1080 count=2 2>/dev/null | hexdump -v -e '/1 "%02x"')" != 53ef ]; then
        mesa_pick
    fi
    # Done with the PS4 filesystem (read-only the whole time).
    scan_stop
    umount /ps4hdd
    msg "hdd: PS4 filesystem unmounted"

    if ! dmsetup --noudevsync create distimg < /run/dist-img.table > /dev/kmsg 2>&1; then
        msg "hdd: dmsetup failed"
        hdd_close
        return 1
    fi
    if [ -n "$tar_size" ] && ! dmsetup --noudevsync create disttar < /run/dist-tar.table > /dev/kmsg 2>&1; then
        tar_size=""
    fi
    magic="$(dd if=/dev/mapper/distimg bs=1 skip=1080 count=2 2>/dev/null | hexdump -v -e '/1 "%02x"')"
    installed=0
    if [ "$magic" != 53ef ]; then
        first_boot_install || { hdd_close; return 1; }
        installed=1
    fi
    [ -b /dev/mapper/disttar ] && dmsetup --noudevsync remove disttar

    if [ "$installed" = 0 ]; then
        /bin/e2fsck -p /dev/mapper/distimg > /dev/kmsg 2>&1
        msg "hdd: e2fsck exit code $?"
        mount -t ext4 /dev/mapper/distimg /newroot || true
    fi
    if ! grep -q ' /newroot ' /proc/mounts || ! has_init; then
        msg "hdd: image does not contain a Linux system"
        umount /newroot 2>/dev/null
        hdd_close
        return 1
    fi
    msg "hdd: booting $DNAME from the PS4 internal drive"
    return 0
}
# ----------------------------------------------------------------------------

# --- USB drives -------------------------------------------------------------
# Mounts a root filesystem on a USB drive (or any device) on /newroot.
dev_boot() {
    msg "mounting $1"
    # Hard power-offs leave the journal dirty; repair before mounting.
    if [ -x /bin/e2fsck ]; then
        /bin/e2fsck -p "$1" > /dev/kmsg 2>&1
        msg "e2fsck exit code $?"
    fi
    mount -o ro "$1" /newroot || { msg "could not mount $1"; return 1; }
    if ! has_init; then
        umount /newroot
        msg "$1 does not contain a Linux system"
        return 1
    fi
}

# Lists "dev id" for every filesystem labeled <NAME>-PS4 outside the PS4 drive.
usb_distros() {
    blkid 2>/dev/null | while read -r line; do
        dev="${line%%:*}"
        case "$dev" in /dev/sd*) ;; *) continue ;; esac
        disk="${dev#/dev/}"; disk="${disk%%[0-9]*}"
        [ -e "/sys/block/$disk/${disk}27" ] && continue
        label="$(echo "$line" | sed -n 's/.* LABEL="\([^"]*\)".*/\1/p')"
        case "$label" in
            PS4BOOT|"") continue ;;
            *-PS4) echo "$dev $(echo "${label%-PS4}" | tr A-Z a-z)" ;;
        esac
    done
}
# ----------------------------------------------------------------------------

# --- Boot screen ------------------------------------------------------------
# Optional logo near the top, the title and credits under it, and the boot
# messages scrolling in the region below so they never cover them.
show_banner() {
    i=0
    while [ ! -e /dev/fb0 ] && [ "$i" -lt 10 ]; do sleep 1; i=$((i + 1)); done
    [ -e /dev/fb0 ] || return 0
    echo 1 > /proc/sys/kernel/printk          # keep kernel messages off the screen
    # The graphical start page right away: no console text before the menu.
    # It stays up (the console is not drawn in graphics mode) until the menu
    # or an install screen replaces it.
    if [ -x /bin/fbui ] && FBUI_TITLE="PS4 Multiboot" fbui msg - "Starting..." 2>/dev/null; then
        return 0
    fi
    rows=$(cut -d, -f2 /sys/class/graphics/fb0/virtual_size 2>/dev/null)
    rows=$(( ${rows:-1080} / 16 ))            # 8x16 console font
    cols=$(( $(cut -d, -f1 /sys/class/graphics/fb0/virtual_size 2>/dev/null || echo 1920) / 8 ))
    printf '\033[2J\033[H\033[?25l' > /dev/console
    top=$(( rows * 20 / 100 ))
    if [ -x /bin/splash ] && [ -f /etc/ps4/splash.rgb ]; then
        splash /etc/ps4/splash.rgb 8
        # Logo ends at 8% + 270 px; text starts two rows under it.
        top=$(( (rows * 8 / 100) + 270 / 16 + 2 ))
    fi
    for line in "PS4 Multiboot" "Credits: blue0x1"; do
        pad=$(( (cols - ${#line}) / 2 )); [ "$pad" -gt 0 ] || pad=0
        printf '\033[%d;%dH%s' "$top" "$((pad + 1))" "$line" > /dev/console
        top=$((top + 1))
    done
    printf '\033[%d;%dr\033[%d;1H' "$((top + 2))" "$rows" "$((top + 2))" > /dev/console
}
# ----------------------------------------------------------------------------

# Keep the Slim/Pro HDMI bridge output on during the initramfs (boot screen,
# menu, install). The distro's ps4-hdmi-keepalive takes over after the switch.
hdmi_pid=""
if [ -x /bin/ps4hdmi ]; then
    ps4hdmi & hdmi_pid=$!
fi
show_banner

msg "initramfs starting"
[ "$rescue" = 1 ] && rescue_shell "rescue shell requested"

# A root given on the command line boots directly, as in Kali for PS4.
if [ -n "$root_spec" ]; then
    i=0; dev=""
    while [ "$i" -lt "$rootwait" ]; do
        case "$root_spec" in
            /dev/*) [ -b "$root_spec" ] && dev="$root_spec" ;;
            *)      dev="$(findfs "$root_spec" 2>/dev/null)" ;;
        esac
        [ -n "$dev" ] && break
        sleep 1; i=$((i + 1))
    done
    if [ -n "$dev" ]; then
        dev_boot "$dev" || rescue_shell "could not boot $root_spec"
    else
        msg "$root_spec not found after ${rootwait}s, showing the menu"
    fi
fi

# Gives a USB drive time to spin up: wait until one with a distro appears,
# at most $rootwait seconds.
usb_list=""
i=0
while [ "$i" -lt "$rootwait" ] && ! grep -q ' /newroot ' /proc/mounts; do
    usb_list="$(usb_distros)"
    [ -n "$usb_list" ] && break
    sleep 1; i=$((i + 1))
done

while ! grep -q ' /newroot ' /proc/mounts; do
    # Collect the cards: "kind|id|where|dev", kind b (boot) or i (install).
    entries=""
    usb_list="$(usb_distros)"
    if [ -n "$usb_list" ]; then
        entries="$(echo "$usb_list" | while read -r dev id; do echo "b|$id|usb|$dev"; done)
"
        echo "$usb_list" | while read -r dev id; do meta_from_root "$id" "$dev"; done
    fi
    if hdd_open; then
        for f in /ps4hdd/home/*-ps4.img; do
            [ -f "$f" ] || continue
            id="${f##*/}"; id="${id%-ps4.img}"
            entries="${entries}b|$id|hdd|
"
            meta_from_root "$id" "$f"
            a="$(archive_of "$id")" && meta_from_archive "$id" "$a"
        done
        for f in /ps4hdd/home/*-ps4-rootfs.tar.xz /ps4hdd/home/*-ps4-rootfs.tar.gz /ps4hdd/home/*-ps4-rootfs.tar.bz2; do
            [ -f "$f" ] || continue
            id="${f##*/}"; id="${id%-ps4-rootfs.tar.*}"
            # Two archives of the same distro: use the first (archive_of order).
            [ "$(archive_of "$id")" = "$f" ] || continue
            [ -f "/ps4hdd/home/$id-ps4.img" ] && continue
            entries="${entries}i|$id|hdd|
"
            meta_from_archive "$id" "$f"
            [ -f "$LOGOS/$id.rgba" ] || scan_archive "$id" "$f"
        done
    fi
    entries="$(echo "$entries" | grep -v '^$')"
    count=$(echo "$entries" | grep -c .)
    ui_answer=""
    ui_back_label="Restart the PS4"
    [ "$count" -gt 1 ] && ui_back_label="Back to the menu"
    msg "found $count: $(echo "$entries" | tr '\n' ' ')"

    if [ "$count" = 0 ]; then
        hdd_close
        rescue_shell "no Linux install or archive found (copy <name>-ps4-rootfs.tar.xz or .tar.gz to /user/home)"
        continue
    fi

    if [ "$count" = 1 ]; then
        # Only one choice: boot it, or show its install screen (with Reboot).
        choice="$entries"
    else
        # The menu: installed systems first (USB, then PS4 drive), then the
        # ones to install, then Reboot.
        set --
        def=0; n=0; timeout=0
        for e in $entries; do
            kind="${e%%|*}"; rest="${e#*|}"; id="${rest%%|*}"; rest="${rest#*|}"; where="${rest%%|*}"
            case "$kind$where" in
                busb) status="USB drive" ;;
                bhdd) status="PS4 drive" ;;
                *)    status="Install" ;;
            esac
            set -- "$@" "$(logo_of "$id")|$(name_of "$id")|$status|$kind"
            if [ "$kind" = b ] && [ "$timeout" = 0 ]; then def=$n; timeout=10; fi
            [ "$kind" = b ] && [ "$id" = "$default_id" ] && def=$n
            n=$((n + 1))
        done
        set -- "$@" "-|Reboot|Restart the PS4|r"
        if [ -x /bin/fbui ]; then
            FBUI_TITLE="PS4 Multiboot" fbui menu - "$def" "$timeout" "$@"
            pick=$?
        else
            pick=$def
        fi
        if [ "$pick" = "$n" ]; then
            UI_IMG=-; ui_reboot
        fi
        choice="$(echo "$entries" | sed -n "$((pick + 1))p")"
        [ -n "$choice" ] || choice="$(echo "$entries" | head -1)"
    fi

    kind="${choice%%|*}"; rest="${choice#*|}"; id="${rest%%|*}"; rest="${rest#*|}"
    where="${rest%%|*}"; dev="${rest#*|}"
    if [ "$kind" = i ] && [ -d "$META/$id/etc/ps4-distro" ] && [ ! -e "$META/$id/scan.done" ] \
       && [ ! -s "$META/$id/etc/ps4-distro/logo.rgba" ]; then
        # Still reading the archive for its logo: wait (at most 2 minutes).
        UI_IMG=-; export FBUI_TITLE="$(name_of "$id") for PS4"
        ui_busy "Reading the $(name_of "$id") archive..."
        scan_wait "$id" 120
        ui_busy_end
    fi
    select_distro "$id"
    msg "chosen: $DNAME ($kind, $where)"

    if [ "$kind$where" = busb ]; then
        hdd_close
        dev_boot "$dev" && break
        back_or_shell "Could not start $DNAME from the USB drive"
        continue
    fi
    if [ "$kind" = i ] && [ "$count" -gt 1 ]; then
        # From the menu: the install screen gets a Back button.
        export FBUI_BACK=1
        ui_welcome
        unset FBUI_BACK
        [ "$install_target" = back ] && continue
    fi
    hdd_boot && break
    hdd_close
    back_or_shell "Could not start $DNAME"
done

ensure_modules

# ps4-linux-loader put this console's own GPU firmware (and its TV's EDID)
# into the initramfs. If amdgpu is a module it loads after the switch, so give
# the distro a copy on tmpfs over its firmware folders.
for fw in amdgpu edid; do
    if [ -d "/lib/firmware/$fw" ] && [ -d "/newroot/usr/lib/firmware" ]; then
        mkdir -p /fwcopy
        mount -t tmpfs -o mode=0755 tmpfs /fwcopy
        cp -a "/newroot/usr/lib/firmware/$fw/." /fwcopy/ 2>/dev/null
        cp -a "/lib/firmware/$fw/." /fwcopy/
        if [ -d "/newroot/usr/lib/firmware/$fw" ]; then
            mount --move /fwcopy "/newroot/usr/lib/firmware/$fw"
            msg "copied loader firmware: $fw ($(ls /newroot/usr/lib/firmware/$fw | wc -l) files)"
        else
            umount /fwcopy
            msg "no /usr/lib/firmware/$fw to cover; skipped"
        fi
    fi
done

msg "switching to ${DNAME:-the root filesystem}"
# The last screen until the system draws its own: "Starting <name>...".
[ -x /bin/fbui ] && fbui msg "${UI_IMG:--}" "Starting ${DNAME:-Linux}..." 2>/dev/null
save_log "root mounted, switching" boot

# Keep copying the kernel log to PS4BOOT for 3 minutes after the switch, so
# problems after the handover can be read later. switch_root deletes this
# initramfs (including busybox), so run a copy of busybox from the FAT32
# partition, which switch_root leaves mounted.
if bd="$(findfs LABEL=PS4BOOT 2>/dev/null)" && mkdir -p /bootfs && mount -t vfat "$bd" /bootfs 2>/dev/null \
   && cp /bin/busybox /bootfs/busybox 2>/dev/null; then
    (
        bb=/bootfs/busybox
        i=0
        while [ "$i" -lt 36 ]; do
            $bb sleep 5
            $bb dmesg > /bootfs/ps4-linux-late.log 2>&1
            $bb sync
            i=$((i + 1))
        done
    ) </dev/null >/dev/null 2>&1 &
fi

# Back to the text console for the system (its login prompt needs it), but
# blank and without a cursor, so no text scene shows before its own screen.
# Its own boot messages stay hidden with "quiet" in bootargs.txt.
[ -x /bin/fbui ] && fbui text
printf '\033[r\033[2J\033[H\033[?25l' > /dev/console 2>/dev/null
[ -n "$hdmi_pid" ] && kill "$hdmi_pid" 2>/dev/null
umount /proc /sys
mount --move /dev /newroot/dev
exec switch_root /newroot /sbin/init
